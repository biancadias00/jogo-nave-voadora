// Criamos nosso estado 'principal' que conterá o jogo 
var mainState = {
    preload: function () {
        // carrega o sprite de cenario
        game.load.image('cenario', 'assets/cenario.png');
        // Carrega o sprite do pássaro 
        game.load.image('nave', 'assets/nn.png');
        // Carrega o sprite do obstaculo 
        game.load.image('obstaculo', 'assets/obt.png');
        // carrega o audio
        game.load.audio('voar', 'assets/jump.wav');
    },
    create: function () {
        // adiciona imagem do cenario
        game.add.sprite(0,0, 'cenario');

        // Configura o sistema de física 
        game.physics.startSystem(Phaser.Physics.ARCADE);
        
        // Mostra a nave na posição x=100 e y=245 
        this.nave = game.add.sprite(100, 245, 'nave');
        
        // Adiciona física a nave 
        // Necessário para: movimentos, gravidade, colisões, etc. 
        game.physics.arcade.enable(this.nave);
        // Adiciona gravidade ao pássaro para fazê-lo cair 
        this.nave.body.gravity.y = 1000;

        // Chama a função 'voar' quando a tecla de espaço é pressionada 
        var spaceKey = game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
        spaceKey.onDown.add(this.voar, this);
        
        // Cria um grupo vazio 
        this.pipes = game.add.group();

        this.timer = game.time.events.loop(2000, this.addRowOfPipes, this);
        
        this.score = 0;
        this.labelScore = game.add.text(20, 20, "0", { font: "30px Arial", fill: "#ffffff" });
        this.nave.anchor.setTo(-0.2, 0.5);
        this.jumpSound = game.add.audio('voar');
    },
    update: function () {
        game.physics.arcade.overlap(this.nave, this.o, this.hitPipe, null, this);
        // Se o pássaro está fora da tela (muito alto ou muito baixo) 
        // Chama a função 'restartGame' 
        if (this.nave.y < 0 || this.nave.y > 600) {
            this.restartGame();
        }
        // se o passaro está em um angulo menor que vinte
        //aumente cada vez mais 1
        if (this.nave.angle < 20) {
            this.nave.angle += 1; 
        }
        
    },

    // Make the nave voar 
    voar: function () {
        if (this.nave.alive == false) {
            return;
        }
        // Add a vertical velocity to the nave
        this.nave.body.velocity.y = -350;

        // cria animação da nave
        var animacao = game.add.tween(this.nave);
        //change angle of nave over time over 100 ms
        animacao.to({angle: -20}, 100);
        //inicia a animação
        animacao.start();

        this.jumpSound.play();
    },
    // Restart the game
    restartGame: function () {
        // Start the 'main' state, which restarts the game
        game.state.start('main');

    },
    addOnePipe: function (x, y) {
        // Cria um obstaculo na posição x e y 
        var obstaculo = game.add.sprite(x, y, 'obstaculo');
        // Adiciona o obstaculo ao nosso grupo criado anteriormente 
        this.pipes.add(obstaculo);
        // Habilita física no obstaculo 
        game.physics.arcade.enable(obstaculo);
        // Adiciona velocidade ao tubo para fazê-lo se mover para a esquerda 
        obstaculo.body.velocity.x = -200;
        // Mata o obstaculo automaticamente quando não está mais visível 
        obstaculo.checkWorldBounds = true;
        obstaculo.outOfBoundsKill = true;
    },
    addRowOfPipes: function () {
        // Escolha aleatoriamente um número entre 1 e 5 
        // Esta será a posição do buraco 
        var hole = Math.floor(Math.random() * 5) + 1;
        // Adiciona os 6 tubos 
        // Com um buraco grande na posição 'hole' e 'hole + 1' 
        for (var i = 0; i < 8; i++) {
            if (i != hole && i != hole + 1) {
                this.addOnePipe(600, i * 80 + 20);
            }
        }
        //this.score ++;
        //this.labelScore.text = this.score;
    },
    hitPipe: function(){
        //if nave has hit a obstaculo, do nothing
        if (this.nave.alive == false) {
            return;
        }
        //set alive propert to false
        this.nave.alive = false;
        //stop pipes from appearing
        game.time.events.remove(this.timer);
        //go through all the pipes, stop their movement
        this.pipes.forEach(function(p){
            p.body.velocity.x =  0;
        }, this);
    }
};
// Inicializa o Phaser e cria um jogo de 400px por 490px 
var game = new Phaser.Game(800, 600);
// Adicione o 'mainState' e chame-o de 'main' 
game.state.add('main', mainState);
// Inicia o estado para realmente iniciar o jogo 
game.state.start('main');













/*
// Criamos nosso estado 'principal' que conterá o jogo 
var mainState = {
    preload: function () {
        // carrega o sprite de cenario
        game.load.image('cenario', 'assets/cenario.png');
        // Carrega o sprite do pássaro 
        game.load.image('nave', 'assets/nn.png');
        // Carrega o sprite do obstaculo 
        game.load.image('obstaculo', 'assets/obt.png');
        // carrega o audio
        game.load.audio('voar', 'assets/jump.wav');
    },
    create: function () {
        // mostra a imagem do cenario
        game.add.sprite(0,0, 'cenario');

        // Configura o sistema de física 
        game.physics.startSystem(Phaser.Physics.ARCADE);
        // Mostra o pássaro na posição x=100 e y=245 
        this.nave = game.add.sprite(100, 245, 'nave');
        // Adiciona física ao pássaro 
        // Necessário para: movimentos, gravidade, colisões, etc. 
        game.physics.arcade.enable(this.nave);
        // Adiciona gravidade ao pássaro para fazê-lo cair 
        this.nave.body.gravity.y = 1000;

        // Chama a função 'voar' quando a tecla de espaço é pressionada 
        var spaceKey = game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
        spaceKey.onDown.add(this.voar, this);
        
        // Cria um grupo vazio 
        this.pipes = game.add.group();

        //adicionando um temporizador 
        this.timer = game.time.events.loop(2000, this.addRowOfPipes, this);
        
        //cria pontuação
        //this.score = 0;
        //this.labelScore = game.add.text(20, 20, "0", { font: "30px Arial", fill: "#ffffff" });
        
        //define a ancora do passaro
        this.nave.anchor.setTo(-0.2, 0.5);

        this.voarSound = game.add.audio('voar');
    },
    update: function () { 
        // Se o pássaro está fora da tela (muito alto ou muito baixo) 
        // Chama a função 'restartGame' 
        if (this.nave.y < 0 || this.nave.y > 600) {
            this.restartGame();
        }
        //Reinicia a jogo sempre que a nave colidir com o obstaculo 
        game.physics.arcade.overlap(this.nave, this.pipes, this.hitPipe, null, this);

        // se o passaro está em um angulo menor que vinte
        //aumente cada vez mais 1
        if (this.nave.angle < 20) {
            this.nave.angle += 1; 
        }
        
    },

    // Faça o pássaro pular
    voar: function () {
        // verifica se a nave esta ativa
        if (this.nave.alive == false) {
            return;
        }
        // Adiciona uma velocidade vertical ao pássaro
        this.nave.body.velocity.y = -350;

        // cria animação da nave
        var animacao = game.add.tween(this.nave);
        // muda o ângulo do pássaro ao longo do tempo em 100 ms
        animacao.to({angle: -20}, 100);
        //inicia a animação
        animacao.start();

        // inicia a funçao 'jumpSound'
        this.jumpSound.play();
    },
    // Reinicia o jogo
    restartGame: function () {
        // Inicia o estado 'principal', que reinicia o jogo
        game.state.start('main');

    },
    addOnePipe: function (x, y) {
        // Cria um obstaculo na posição x e y 
        var obstaculo = game.add.sprite(x, y, 'obstaculo');
        // Adiciona o obstaculo ao nosso grupo criado anteriormente 
        this.pipes.add(obstaculo);
        // Habilita física no obstaculo 
        game.physics.arcade.enable(obstaculo);
        // Adiciona velocidade ao tubo para fazê-lo se mover para a esquerda 
        obstaculo.body.velocity.x = -200;
        // Mata o obstaculo automaticamente quando não está mais visível 
        obstaculo.checkWorldBounds = true;
        obstaculo.outOfBoundsKill = true;
    },
    addRowOfPipes: function () {
        // Escolha aleatoriamente um número entre 1 e 5 
        // Esta será a posição do buraco 
        var hole = Math.floor(Math.random() * 5) + 1;
        // Adiciona os 6 tubos 
        // Com um buraco grande na posição 'hole' e 'hole + 1' 
        for (var i = 0; i < 8; i++) {
            if (i != hole && i != hole + 1) {
                this.addOnePipe(600, i * 80 + 20);
            }
        }

        // acrescenta +1 na pontuação
        //this.score ++;
        //this.labelScore.text = this.score;
    },
    hitPipe: function(){
        //se o pássaro atingiu um cano, não faça nada
        if (this.nave.alive == false) {
            return;
        }
        //defina uma propriedade ativa para false
        this.nave.alive = false;
        //impede que os pipes apareçam
        game.time.events.remove(this.timer);
        //passa por todos os canos, para o movimento deles
        this.pipes.forEach(function(p){
            p.body.velocity.x =  0;
        }, this);
    }
};
// Inicializa o Phaser e cria um jogo de 400px por 490px 
var game = new Phaser.Game(800, 600);
// Adicione o 'mainState' e chame-o de 'main' 
game.state.add('main', mainState);
// Inicia o estado para realmente iniciar o jogo 
game.state.start('main');

*/